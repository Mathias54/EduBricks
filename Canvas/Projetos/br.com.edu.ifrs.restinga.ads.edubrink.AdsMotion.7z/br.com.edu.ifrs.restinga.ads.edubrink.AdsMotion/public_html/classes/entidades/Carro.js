/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Carro(cor, velocMaxima, carName){

    this.cor = cor;
    this.velocMaxima = velocMaxima;
    this.velocidade = 0;
    this.carName = carName;
    this.posicao = -30;
    this.orientacao = true;  //true:direita //false:esquerda
    
    this.acelerar = function(){

        if(this.velocidade < velocMaxima){
            this.velocidade++;
        }

    };
    
    this.frear = function(){

        if(this.velocidade > 0){
            this.velocidade--;
        }

    };

    this.getCarName = function(){
        return (this.carName);
    };

    this.getPosicao = function(){
        return (this.posicao);
    };

    this.getOrientacao = function(){
        return(this.orientacao);
    };

    this.motion = function(){

        if(this.orientacao){
            this.posicao += this.velocidade;
        }
        else{
            this.posicao -= this.velocidade;
        }

        if(this.posicao < -200 || this.posicao > 1000){

            if(this.posicao < -400){
                this.orientacao = true;
            }
            else if(this.posicao > 1150){
                this.orientacao = false;
            }
            else{

                if(this.velocidade > 8){
                    velocidade -= 8;
                }

            }

        }

        if((Math.random() * 10) > 5){
            this.acelerar();
        }

    };

}

function Competicao(carros){
    
    var carroAtual;
    this.carros = carros;

    this.competir = function(){

        if(this.carros <= 1){
            alert("Competidores insuficientes!");
        }
        else{

            for(var i = 0; i < this.carros.length; i++){

                carroAtual = carros[i];
                console.log(carroAtual.getPosicao());

                for(var y = 0 ; y < this.carros.length; y++){

                    if(y !== i){

                        if(this.carroAtual.getOrientacao() === this.carros[y].getOrientacao()){

                           if(this.carroAtual.getOrientacao() === true){

                               if(this.carroAtual.getPosicao() <= this.carros[y].getPosicao()){
                                    this.carroAtual.acelerar();
                               } 

                           }
                           else{

                               if(this.carroAtual.getPosicao() >= this.carros[y].getPosicao()){
                                   this.carroAtual.acelerar();
                               }

                           }

                        }

                    }

                }

            }

        }

    };
    
};
