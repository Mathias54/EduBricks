/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Bola(context, x, y, velocidadeX, velocidadeY, cor, raio){
    
    this.context = context;
    this.x = x;
    this.y = y;
    this.velocidadeX = velocidadeX;
    this.velocidadeY = velocidadeY;
    
    this.cor = cor;
    this.raio = raio;
  
}

Bola.prototype = {
        
        atualizar: function(){

            if(this.x < this.raio || this.x > this.context.canvas.width - this.raio){
                this.velocidadeX *= -1;
            }

            if(this.y < this.raio || this.y > this.context.canvas.height - this.raio){
                this.velocidadeY *= -1;
            }

            this.x += this.velocidadeX;
            this.y += this.velocidadeY;
            
        },
        desenhar: function() {
            
            this.context.save();
            this.context.beginPath();
            this.context.fillStyle = this.cor;
            this.context.arc(this.x, this.y, this.raio, 0, 2 * Math.PI, false);
            this.context.fill();
            
            this.context.restore();
            
        },
        retangulosColisao: function(){
            
            return[{ x: this.x - this.raio,
                     y: this.y - this.raio,
                     largura: this.raio * 2,
                     altura:  this.raio * 2 }];
            
        },
        colidiuCom: function(sprite){
            
            if(this.x < sprite.x){
                this.velocidadeX = -Math.abs(this.velocidadeX);
            }
            else{
                this.velocidadeX = Math.abs(this.velocidadeX);
            }
            
            if(this.y < sprite.y){
                this.velocidadeY = -Math.abs(this.velocidadeY);
            }
            else{
                this.velocidadeY = Math.abs(this.velocidadeY);
            }
            
        }
       
    };