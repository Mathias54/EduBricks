/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var DIREITA = 1;
var ESQUERDA = 2;

function Heroi(context, teclado, animacao, imagem, x, y){
    
    this.context = context;
    this.teclado = teclado;
    this.animacao = animacao;
    
    this.x = x;
    this.y = y;
    this.velocidade = 10;
 
    this.sheet = new Spritesheet(this.context,imagem,3,8);
    this.sheet.intervalo = 60;
    
    this.andando = false;
    this.direcao = DIREITA;
 
}

Heroi.prototype = {
    
    atualizar: function(){
        
        if(this.teclado.pressionada(SETA_DIREITA)){
            
            if(!this.andando || this.direcao !== DIREITA){
            
                this.sheet.linha = 1;
                this.sheet.coluna = 0;
            
            }
            
            this.andando = true;
            this.direcao = DIREITA;
            
            this.sheet.proximoQuadro();
            this.x += this.velocidade;
            
        }
        else if(this.teclado.pressionada(SETA_ESQUERDA)){
            
            if(!this.andando || this.direcao !== ESQUERDA){
                
                this.sheet.linha = 2;
                this.sheet.coluca = 0;
                
            }
            
            this.andando = true;
            this.direcao = ESQUERDA;
            this.sheet.proximoQuadro();
            this.x -= this.velocidade;
            
        }
        else{
            
            if(this.direcao === DIREITA){
                this.sheet.coluna = 0;
            }
            else if(this.direcao === ESQUERDA){
                this.sheet.coluna = 1;
            }
            
            this.sheet.linha = 0;
            this.andando = false;
            
        }
        
    },
    desenhar: function(){
        this.sheet.desenhar(this.x, this.y);
    },
    atirar: function(){
        
        var tiro = new Bola(this.context, (this.x + (Math.random()*10)), (this.y + 10), 0, 0, 'red', 2, false);
        
        if(this.direcao === DIREITA){
            tiro.velocidadeX = 20;
        }
        else{
            tiro.velocidadeX = -20;
        }
        
        this.animacao.novoSprite(tiro);
        
    }
    
};