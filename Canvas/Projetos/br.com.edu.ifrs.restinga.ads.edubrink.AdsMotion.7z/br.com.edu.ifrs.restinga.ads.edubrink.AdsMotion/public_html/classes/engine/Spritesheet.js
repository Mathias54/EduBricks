/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Spritesheet(context, imagem, linhas, colunas){
    
    this.context = context;
    this.imagem = imagem;
    this.numLinhas = linhas;
    this.numColunas = colunas;
    this.intervalo = 0;
    this.linha = 0;
    this.coluna = 0;
    
}

Spritesheet.prototype = {
    
    proximoQuadro : function(){
        
        var tempo = new Date().getTime();
        
        if(!this.ultimoTempo){
            this.ultimoTempo = tempo;
        }
        
        if(tempo - this.ultimoTempo < this.intervalo){
            return;
        }
        
        if(this.coluna < this.numColunas - 1){
            this.coluna++;
        }
        else{
            this.coluna = 0;
        }
        
        this.ultimoTempo = tempo;
        
    },
    desenhar: function(x, y){
        
        var larguraQuadro = this.imagem.width / this.numColunas;
        var alturaQuadro = this.imagem.height / this.numLinhas;
        
        this.context.drawImage(
                this.imagem, 
                larguraQuadro * this.coluna,
                alturaQuadro * this.linha,
                larguraQuadro,
                alturaQuadro,
                x,
                y,
                larguraQuadro,
                alturaQuadro);
        
    }

};