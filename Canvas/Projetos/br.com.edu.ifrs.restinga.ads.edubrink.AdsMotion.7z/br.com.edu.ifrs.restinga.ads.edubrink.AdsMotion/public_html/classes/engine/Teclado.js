/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var SETA_ESQUERDA = 37;
var SETA_DIREITA = 39;
var ESPACO = 32;

function Teclado(elemento){
    
    this.elemento = elemento;
    this.pressionadas = [];
    this.disparadas = [];
    this.funcoesDisparo = [];
    
    var teclado = this;
    
    elemento.addEventListener('keydown', function(evento){
        
        teclado.pressionadas[evento.keyCode] = true;
        
        if(teclado.funcoesDisparo[evento.keyCode] 
                && !teclado.disparadas[evento.keyCode]){
            
            teclado.disparadas[evento.keyCode] = true;
            teclado.funcoesDisparo[evento.keyCode]();
            
        }
        
    });
    
    elemento.addEventListener('keyup', function(evento){
        
        teclado.pressionadas[evento.keyCode] = false;
        teclado.disparadas[evento.keyCode] = false;
        
    });
    
}

Teclado.prototype = {
    
    pressionada : function(tecla){
        return this.pressionadas[tecla];
    },
    disparou : function(tecla, callback){
        this.funcoesDisparo[tecla] = callback;
    }
    
}
