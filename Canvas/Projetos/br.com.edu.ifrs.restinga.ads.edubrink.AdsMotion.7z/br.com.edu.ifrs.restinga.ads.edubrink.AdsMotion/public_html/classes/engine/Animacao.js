/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Animacao(context, cenario){
    
    this.context = context;
    this.sprites = [];
    this.ligado = false;
    this.cenario = cenario;

}

Animacao.prototype = {
    
    novoSprite: function(sprite){
        this.sprites.push(sprite);
    },
    
    ligar: function(){
        this.ligado = true;
        this.proximoFrame();
    },
    
    desligar: function(){
        this.ligado = false;
    },
    
    proximoFrame: function(){
        
        if(!this.ligado){
            return;
        }
        
        this.limparTela();
        
        for(var i in this.sprites){
            this.sprites[i].atualizar();
        }
        
        for(var i in this.sprites){
            this.sprites[i].desenhar();
        }
        
        var animacao = this;
        
        requestAnimationFrame(function(){
            animacao.proximoFrame();
        });
        
    },
    
    limparTela: function(){
        
        this.context.clearRect(0, 
                               0, 
                               this.context.canvas.width, 
                               this.context.canvas.height);
        
        if(this.cenario !== null){
            this.context.drawImage(this.cenario,
                                   0,
                                   0,
                                   this.context.canvas.width,
                                   this.context.canvas.height);
        }
    
    }
    
};
