/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Fundo(context, imagem, velocidade){
    
    this.context = context;
    this.imagem = imagem;
    this.velocidade = velocidade;
    this.posicaoEmenda = 0;
    
}

Fundo.prototype = {
    
    atualizar: function() {
    
        this.posicaoEmenda += this.velocidade;
        
        if(this.posicaoEmenda > this.imagem.height){
            this.posicaoEmenda = 0;
        }
    
    },
    desenhar: function(){
        
        var posicaoY = this.posicaoEmenda - this.imagem.height;
        this.context.drawImage(this.imagem, 0, posicaoY, this.imagem.width, this.imagem.height);
        
        posicaoY = this.posicaoEmenda;
        this.context.drawImage(this.imagem, 0, posicaoY, this.imagem.width, this.imagem.height);
        
    }

};
    